/** LogMessageOne.java -- Logging routines for single message tests
**/
package com.etantdonnes.tinyos.robo;

import java.io.PrintStream;

public class LogMessageOne implements LogMessage
{
	protected PrintStream out = null;	// output stream
	
	/**
	 * 
	 */
	public LogMessageOne( PrintStream o )
	{
		super();
		out = o;
	}

	/* (non-Javadoc)
	 * @see com.etantdonnes.tinyos.robo.LogMessage#startLog()
	 */
	public void startLog( long start )
	{
		// TODO: Nothing
	}

	/* (non-Javadoc)
	 * @see com.etantdonnes.tinyos.robo.LogMessage#stopLog()
	 */
	public void stopLog()
	{
		// TODO: Nothing
	}

	/* (non-Javadoc)
	 * @see com.etantdonnes.tinyos.robo.LogMessage#logWrite(long, boolean, com.etantdonnes.tinyos.robo.RoboStatReq)
	 */
	public void logWrite( long now, boolean acked, RoboStatReq statReq )
	{
		out.println( statReq.toString() );
	}

	/* (non-Javadoc)
	 * @see com.etantdonnes.tinyos.robo.LogMessage#logRead(com.etantdonnes.tinyos.robo.RoboStatMsg)
	 */
	public void logRead( RoboStatMsg msg )
	{
		out.println( msg.toString() );
	}

}
