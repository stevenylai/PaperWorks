/** RoboStopReq.java -- format RoboCar STOP request message.
**/
package com.etantdonnes.tinyos.robo;


/** motion immediate stop request -- no payload
**/
public class RoboStopReq extends RoboStatReq
{
	public RoboStopReq()
	{
		super(  RoboMessage.DESTADDR,	// destination mote ID
				RoboMessage.AM_ROBOCMDSTOPMSG,
				RoboMessage.GROUPID,	// group ID
				RoboMessage.PKTSIZE,	// default pktsize
				RoboMessage.SOURCEID ); // source ID...nada diff too
	}

} // end'o'RoboStopReq
