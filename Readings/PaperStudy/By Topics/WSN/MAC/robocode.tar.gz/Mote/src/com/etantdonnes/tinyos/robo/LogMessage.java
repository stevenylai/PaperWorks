/** LogMessage.java -- Logging interface for CommTests.
 *   Extracted so we can make different behaviors in the ReadThread.
 */
package com.etantdonnes.tinyos.robo;

import java.io.PrintStream;

/**
 * @author schip
 */
public interface LogMessage
{
	/** initialize and start logging 
	 *
	 * * @param start -- CurrentTime when we started writing
	 */
	public void startLog( long start );

	/** stop the log and write any wrapup stuff
	 */
	public void stopLog();

	/** log a message write (Status Request)
	 * 
	 * @param now -- CurrentTime when we started writing
	 * @param acked -- was the message ACKed?
	 * @param statReq -- The request object we used
	 */
	public void logWrite( long now,
						  boolean acked,
						  RoboStatReq statReq );

	/** log a message received (Status Reply)
	 * 
	 * @param msg -- received Status message
	 */
	public void logRead( RoboStatMsg msg );
}