/** RoboStatReq.java -- format RoboCar START motion request message.
**/
package com.etantdonnes.tinyos.robo;


/** motion start request -- sends a whole load of parameters
 **/
public class RoboStartReq extends RoboStatReq
{
    public int runstate;		// Running state bitfield
    public int movetime;		// Timer ticks for running motion (+/-)
    public int turntime;		// Timer ticks for turning motion (+/-)
    public int movespeed;		// motor speed for running motion
    public int turnspeed;		// motor speed for turning motion
    public int pingA0cnt;		// Position sensor ping timer 0-1
    public int pingB0cnt;		// Position sensor ping timer 1-2
    public int targetData;		// Target sensor search data
    public int otherData;		// Other sensor search data

	public RoboStartReq()
	{
		super(  RoboMessage.DESTADDR,	// destination mote ID
				RoboMessage.AM_ROBOCMDSTARTMSG,
				RoboMessage.GROUPID,	// group ID
				RoboMessage.PKTSIZE,	// default pktsize
				RoboMessage.SOURCEID ); // source ID...nada diff too
	}

	/** Parse a message packet into our local fields.
	 *  @param -- byte array containing data read from Mica2.
	 *  @return -- true if OK,
	 *  		   false if something wrong with packet.
	 *
	 * NOTE: all the offsets and sizes are hard coded here...
	 * NOTE2: this method is superflous because we never Get a startReg
	 *         we only send them.
	 *   It's here for reference because I already implemented it...
	 ***/
	public boolean parse( byte[] p )
	{
		boolean rval = false;

		if( super.parse( p ) == true )
		{
			// get local values
    		runstate		= ti(p, 9) & 0xffff;
    		movetime		= ti(p, 11) & 0xffff;
    		turntime		= ti(p, 13) & 0xffff;
			movespeed		= p[15] & 0xff;
			turnspeed		= p[16] & 0xff;
    		pingA0cnt		= ti(p, 17) & 0xffff;
    		pingB0cnt		= ti(p, 19) & 0xffff;
    		targetData		= p[21] & 0xff;
    		otherData		= ti(p, 22) & 0xffff;

			rval = true;	// A-OK
		}

		return rval;
	}

	/** set common fields in given data buffer
	 **/
	public void setFields( byte[] p )
	{
		super.setFields( p );

		fi( runstate, p, 9);
		fi( movetime, p, 11);
		fi( turntime, p, 13);
		p[15] = (byte) (movespeed & 0xff);
		p[16] = (byte) (turnspeed & 0xff);
		fi( pingA0cnt, p, 17);
		fi( pingB0cnt, p, 19);
		p[21] = (byte) (targetData & 0xff);
		fi( otherData, p, 22);

		return;
	}

	/** set all the local fields to 0 
	 * @return nada
	 **/
	public void clearPacket()
	{
		runstate		= 0;
		movetime		= 0;
		turntime		= 0;
		movespeed		= 0;
		turnspeed		= 0;
		pingA0cnt		= 0;
		pingB0cnt		= 0;
		targetData		= 0;
		otherData		= 0;

		return;
	}

	/** convert local message data to readable format
	 **/
	public String toString()
	{
		return(
				super.toString() +
				"rs=" + Integer.toHexString( runstate ) +
				" mt=" + movetime +
				" tt=" + turntime +
				" ms=" + movespeed +
				" ts=" + turnspeed +
				" a0=" + pingA0cnt +
				" b0=" + pingB0cnt +
				" td=" + targetData +
				" od=" + otherData
			  );
	}

} // end'o'RoboStartReq