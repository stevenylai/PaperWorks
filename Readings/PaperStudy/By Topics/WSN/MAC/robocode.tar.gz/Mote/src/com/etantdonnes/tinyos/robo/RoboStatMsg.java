/** RoboStatMsg.java -- RoboCar STATUS reply message from Mote.
**/
package com.etantdonnes.tinyos.robo;


/** status message received from Mica2
 * Generally this message will be received as a raw buffer from the mote.
 *  The buffer will be stuck into the data area of this message class
 *  and then parsed appropriately.  
 **/
public class RoboStatMsg extends RoboMessage
{
	// extra components of the RoboStatMsg itself
    public int runstate;		// Running state and result bitfield
    public int movetime;		// Timer ticks while in running motion (+/-)
    public int turntime;		// Timer ticks while in turning motion (+/-)
    public int bumpers;			// Collision and Proximity bitmap
    public int batvoltage;		// Battery voltage reading
    public int batcharge;		// Battery charge reading (+/-)
    public int pingA0cnt;		// Position sensor ping timer 0-1
    public int pingB0cnt;		// Position sensor ping timer 1-2
    public int pingA1cnt;		// Position sensor ping timer 0-1 previous val
    public int pingB1cnt;		// Position sensor ping timer 1-2 previous val
    public int targetData;		// Target sensor received data
    public int targetStrength;	// Target sensor signal strength
    public int otherData;		// Other sensor received data
    
    // used for message analysis
    public int rssi;			// received signal strength at reMote
    public int noacks;			// ACKs missed since last command msg
    public int nomsgs;			// messages missed (seqno difference)


	public RoboStatMsg()
	{
	}

	/** Parse a message packet into our local fields.
	 *  @param -- byte array containing data read from Mica2.
	 *  @return -- true if OK,
	 *  		   false if something wrong with packet.
	 *
	 * NOTE: all the offsets and sizes are hard coded here...
	 **/
	public boolean parse( byte[] p )
	{
		boolean rval = false;

		if( super.parse( p ) == true )
		{
    		runstate		= ti(p, 9) & 0xffff;
    		movetime		= tim(p, 11) & 0xffff;
    		turntime		= tim(p, 13) & 0xffff;
    		bumpers			=    p[15] & 0xff;
    		batvoltage		=    p[16] & 0xff;
    		batcharge		=    p[17] & 0xff;
    		pingA0cnt		= ti(p, 18) & 0xffff;
    		pingB0cnt		= ti(p, 20) & 0xffff;
    		pingA1cnt		= ti(p, 22) & 0xffff;
    		pingB1cnt		= ti(p, 24) & 0xffff;
    		targetData		= ti(p, 26) & 0xffff;
    		targetStrength	= ti(p, 27) & 0xffff;
    		otherData		= ti(p, 28) & 0xffff;
    		rssi			= ti(p, 30) & 0xffff;
    		noacks			=    p[32] & 0xff;
    		nomsgs			=    p[33] & 0xff;

			rval = true;	// A-OK
		}

		return rval;
	}
	
	/** no point in implementing a setFields() method
	 *   because we only use this to Get messages, not send
	 */

	/** set all the local fields to 0 
	 * @return nada
	 **/
	public void clearPacket()
	{
		runstate		= 0;
		movetime		= 0;
		turntime		= 0;
		bumpers			= 0;
		batvoltage		= 0;
		batcharge		= 0;
		pingA0cnt		= 0;
		pingB0cnt		= 0;
		pingA1cnt		= 0;
		pingB1cnt		= 0;
		targetData		= 0;
		targetStrength	= 0;
		otherData		= 0;
		rssi			= 0;
   		noacks			= 0;
   		nomsgs			= 0;

		return;
	}

	/** convert local message data to readable format
	 **/
	public String toString()
	{
		return(
				super.toString() +
				"rs=" + Integer.toHexString( runstate ) +
				" mt=" + movetime +
				" tt=" + turntime +
				" bm=" + Integer.toHexString( bumpers ) +
				" bl=" + batvoltage +
				" bc=" + batcharge +
				" a0=" + pingA0cnt +
				" b0=" + pingB0cnt +
				" a1=" + pingA1cnt +
				" v1=" + pingB1cnt +
				" td=" + targetData +
				" ts=" + targetStrength +
				" od=" + otherData +
				" rs=" + rssi +
				" na=" + noacks +
				" nm=" + nomsgs
			  );
	}

} // end'o'RoboStatMsg