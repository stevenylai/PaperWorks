/** RoboStatReq.java -- format RoboCar STATUS request message.
**/
package com.etantdonnes.tinyos.robo;


/** Status request message...
 *    conveys some logging and messaging parameters for comm testing
 **/
public class RoboStatReq extends RoboMessage
{
	// extra components of the RoboStatReq itself
	// used for radio testing
    public int runstate;		// Running state
    public int txstrength;		// transmit strength to use from here on...
    public int rxdelay;			// ms to delay response -- not impl
    
    // state indicators
    public static final int SRSnoack	= 0x0001;	// shutoff ACK behavior
    public static final int SRSnorpt    = 0x0002;	// don't repeat un-ACK msgs
    // note: rndrx not implemented...
    public static final int SRSrndrx    = 0x0004;	// do random reply timeing
    
    
	public RoboStatReq()
	{
		this(  RoboMessage.DESTADDR,	// destination mote ID
				RoboMessage.AM_ROBOCMDSTATMSG,
				RoboMessage.GROUPID,	// group ID
				RoboMessage.PKTSIZE,	// default pktsize
				RoboMessage.SOURCEID ); // source ID...nada diff too
	}

	/** for use by request sub-classes -- allocates message data buffer
	 **/
	protected RoboStatReq( int da, int hid, int gid, int len, int sid )
	{
		super( da, hid, gid, len, sid );
		data = new byte[RoboMessage.MSGSIZE];
	}
	
	/** no point in implementing a parse() method
	 *   because we only use this to Send messages, not get
	 */

	/** set component fields in given data buffer
	 **/
	public void setFields( byte[] p )
	{
		super.setFields( p );

		fi( runstate, p, 9);
		fi( txstrength, p, 11);
		fi( rxdelay, p, 13);

		return;
	}
	
	/** set all our fields to 0 
	 * @return nada
	 **/
	public void clearPacket()
	{
		runstate	= 0;
	    txstrength = 0;
	    rxdelay = 0;	

		return;
	}

	/** convert local message data to readable format
	 **/
	public String toString()
	{
		return(
				super.toString() +
				"rs=" + Integer.toHexString( runstate ) +
				" tx=" + txstrength +
				" rx=" + rxdelay
			  );
	}

} // end'o'RoboStatReq