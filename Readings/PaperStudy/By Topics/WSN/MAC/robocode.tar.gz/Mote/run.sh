java -classpath "classes/rct.jar\;classes/tinytools.jar" RadioCommTest
