/** RoboMsg.h -- Message structure and types for RoboII.
 **		Each of the message packets has up to 29 bytes of unaligned stuff
 **		overlaid on the .data field of the TOS_Msg that is sent and received.
 **/

#include "AM.h"

/* #define M2	/* if using mica2, allows MacControl and stuff */

/** Message types
 **/
enum
{
  // Status Reply to Host (Send)
  AM_ROBOSTATUSMSG = 10,
  // Host Commands (Receive)
  AM_ROBOCMDSTARTMSG = 32,	// Start motion
  AM_ROBOCMDSTOPMSG,		// Stop immediately
  AM_ROBOCMDSTATMSG			// Status: return current status
};


/** Status return package
 **/
typedef struct
{
    							// byte number in buffer (start from 0)
    uint16_t sourceMoteID;		//  5 Assigned MoteID and RoboII device ID
    uint16_t sequenceNumber;	//  7 Message sequence number
    uint16_t runstate;			//  9 Running state and result bitfield
    int16_t movetime;			// 11 Timer ticks while in running motion (+/-)
    int16_t turntime;			// 13 Timer ticks while in turning motion (+/-)
    uint8_t bumpers;			// 15 Collision and Proximity bitmap
    uint8_t batvoltage;			// 16 Battery voltage reading
    int8_t batcharge;			// 17 Battery charge reading (+/-)
    uint16_t pingA0cnt;			// 18 Position sensor ping timer 0-1
    uint16_t pingB0cnt;			// 20 Position sensor ping timer 1-2
    uint16_t pingA1cnt;			// 22 Position sensor ping timer 0-1 previous val
    uint16_t pingB1cnt;			// 24 Position sensor ping timer 1-2 previous val
    uint8_t targetData;			// 26 Target sensor received data
    uint8_t targetStrength;		// 27 Target sensor signal strength
    uint16_t otherData;			// 28 Other sensor received data
    uint16_t rssi;				// 30 radio signal strength, received
    uint8_t noacks;				// 32 ACKs missed since last msg
    uint8_t nomsgs;				// 33 msgs missed (serial# difference)
	     // 29 bytes

    // uint8_t data[0];	// leftover -- to total 29 bytes in data buf
} RoboStatusMsg;

/** Host Command package 
 **/
typedef struct
{
    uint16_t sourceMoteID;		//  5 source ID
    uint16_t sequenceNumber;	//  7 Message sequence number
    uint16_t runstate;			//  9 Running state bitfield
    int16_t movetime;			// 11 Timer ticks for running motion (+/-)
    int16_t turntime;			// 13 Timer ticks for turning motion (+/-)
    uint8_t movespeed;			// 15  motor speed for running motion
    uint8_t turnspeed;			// 16 motor speed for turning motion
    uint16_t pingA0cnt;			// 17 Position sensor ping timer 0-1
    uint16_t pingB0cnt;			// 19 Position sensor ping timer 1-2
    uint8_t targetData;			// 21 Target sensor search data
    uint16_t otherData;			// 22 Other sensor serch data
    uint8_t motordiff;			// 24 motor speed differential for line corr
		// 20 bytes

    uint8_t data[9];	// leftover -- to total 29 bytes
} RoboCmdMsg;


/** Host Status request package 
 **   sets some interesting stuff for radio comm analysis
 **/
typedef struct
{
    uint16_t sourceMoteID;		//  5 source ID
    uint16_t sequenceNumber;	//  7 Message sequence number
    uint16_t runstate;			//  9 Running state bitfield
    uint16_t txstrength;		// 11 Transmit power to use
    uint16_t rxdelay;			// 13 ms to delay status response
		// 10 bytes

    uint8_t data[19];	// leftover -- to total 29 bytes
} RoboStatReq;
 
// runstate indicators for above
enum
{
	SRSnoack = 0x0001,	// shutoff ACK behavior
	SRSnorpt = 0x0002,	// don't repeat un-ACKed msgs
	SRSrndrx = 0x0004	// do random reply timing
};


/** Control structure -- not a message, but easier to put in this file...
 *		Contains all the little nibbly bits for inter-module control.
 **/
/** Robo Monitor -- monstate bitfield
 **/
enum
{
  RM_NONE		= 0x0000,	// Reset...

  // Robot states
  RMS_RUN		= 0x0001,	// motion in progress
  RMS_MORE		= 0x0002,	// in first part of turn/move motion
  RMS_MOVE		= 0x0004,	// moving fwd/bkwd
  RMS_TURN		= 0x0008,	// rotating
  RMS_TRACK		= 0x0010,	// acquiring/tracking target
  RMS_DOSHUFFLE	= 0x0020,	// enable shuffle when radio commands are lost

  // Motion completion events
  RM_TIMEOUT	= 0x0100,	// timeout, using time field
  RM_BATTERY	= 0x0200,	// battery condition
  RM_COLLISION	= 0x0400,	// collision sensor
  RM_BUMPERS	= 0x0800,	// proximity sensor, non-contact 'bumpers'
  RM_POSITION	= 0x1000,	// position sensor, using targetId field
  RM_TARGET		= 0x2000,	// target sensor, acquisition using targetId field
  RM_OTHER		= 0x4000,	// other robot sensor, using otherId field

};

typedef struct
{
    uint16_t monstate;		// Input monitor indicators bitfield
    uint16_t ticks;			// number of timer ticks since motion started
    uint16_t time;			// number of timer ticks for current motion
	uint16_t curbump;		// current bumper input
	uint16_t startbump_i;	// bumper reading before starting motion, inverted
	uint16_t bumpdelay;		// bumper sensor delay (to ignore bumpers)
	uint16_t statticks;		// ticks since last status message
    uint16_t targetId;		// Target sensor search data
    uint16_t otherId;		// Other robot sensor data

    uint8_t crap;		// stuff
} RoboControl;

