// $Id: PWMhardware
/*									tab:4
 * "Copyright (c) The Regents of the University  of California.  
 *    Modified from cotsbots hardware.h by MSchippling SFI 2004
 * All rights reserved.
 *
 * header file for PWM and motor control hardware
 */
 
#ifndef PWMHARDWARE_H
#define PWMHARDWARE_H
 
// Not needed because it is implicitly included....somewhere...
//#include <hardware.h>		// get the standard defs from platform/mica2

/**/
  enum {
    MOTOR_FORWARD = 1,
    MOTOR_REVERSE = 0,
    MOTOR_OFF = 0
  };
/**/

/** after cotsbots motor/hardware.h for PWM output: **/
// it appears that the PWM and DIR appellations are reversed
//  and also that the pins assigned to PWM (sic) are not available
//  due to their being used by the radio:
//      PB1 -- SPI_SCK
//      PB2 -- SPI_MOSI
//  so gotta try somethong else....

TOSH_ASSIGN_PIN(MOTOR1DIR, C, 0);	// PC0 
TOSH_ASSIGN_PIN(MOTOR1PWM, B, 6);	// PB6

TOSH_ASSIGN_PIN(MOTOR2DIR, C, 1);	// PC1
TOSH_ASSIGN_PIN(MOTOR2PWM, B, 5);	// PB5

#endif // not PWMHARDWARE_H




