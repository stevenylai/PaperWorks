/** RoboHardware.h -- Definitions for ATMEGA connections on RoboSensor board.
**/

#ifndef ROBOHARDWARE_H
#define ROBOHARDWARE_H	// prevent multiple inclusions
 
// Not needed because it is implicitly included....somewhere...
// #include <hardware.h>		// get the standard defs from platform/mica2

/**
      Function           Board       MICA    ATMEGA pin
	Radio Strength		RSSI		ADC0       PF0
	Target Sensor		PhotoIN		ADC1       PF1
	Battery Current 	VBat		ADC3       PF3
	Battery Level   	VBat		ADC7       PF3
	Bumper Sensors		PW0-3		PW0-3      PC0-3
	Collision Sensor	Wall*		PW7        PC7
	Sonar Pinger		SonarIN		INT3       PE7

	Motor Drive			PWMout		PWM1aout   PB5
	Motor Drive			PWMout		PWM1bout   PB6
**/

/** ADC numbers for various sensors.
 *   note that #defines don't work, have to use enum...??!
 */
enum
{
	ROBOADC_RADIO		=	0,
	ROBOADC_TARGET		=	1,
	ROBOADC_BCURRENT	=	3,
	ROBOADC_BVOLTAGE	=	7
};

/** input pin for Sonar timer **/
TOSH_ASSIGN_PIN( SONARPING, E, 7 );	// PE7

/** PWM output pins: **/
TOSH_ASSIGN_PIN(MOTOR1PWM, B, 5);	// PB5
TOSH_ASSIGN_PIN(MOTOR2PWM, B, 6);	// PB6


/* definitions for servo motor directions used in HPLMotorIII */
  enum
{
    MOTOR_FORWARD = 1,
    MOTOR_REVERSE = 0,
    MOTOR_OFF = 0
};

/** Proiximity sensor bits **/
#define BUMPERS		0x0f
/** Colision sensor bit **/
#define	COLLISION	0x10


#endif // not ROBOHARDWARE_H




